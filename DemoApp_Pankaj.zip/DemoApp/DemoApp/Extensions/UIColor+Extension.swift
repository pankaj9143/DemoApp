//
//  UIColor+Extension.swift
//  DemoApp
//
//  Created by Pankaj Purohit on 26/08/22.
//

import Foundation
import UIKit

extension UIColor {
    static let darkPurpleColor = UIColor(named: "darkPurpleColor")!
}
