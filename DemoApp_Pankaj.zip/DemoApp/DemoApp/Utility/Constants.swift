//
//  Constants.swift
//  DemoApp
//
//  Created by Pankaj Purohit on 26/08/22.
//

import Foundation

let APP_NAME = "DemoApp"
let MSG_NETWORK_ERROR = "Network Unavailable"

let SERVER_URL  =  "https://api.github.com/"
let WS_USERS = "users"

