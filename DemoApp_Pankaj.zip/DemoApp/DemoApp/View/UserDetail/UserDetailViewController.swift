//
//  UserDetailViewController.swift
//  DemoApp
//
//  Created by Pankaj Purohit on 26/08/22.
//

import UIKit
import RxSwift
import Kingfisher

class UserDetailViewController: UIViewController {
    @IBOutlet private weak var imgUser: UIImageView!
    @IBOutlet private weak var lblUserName: UILabel!
    @IBOutlet private weak var lblLocation: UILabel!
    @IBOutlet private weak var lblFollower: UILabel!
    @IBOutlet private weak var lblFollowing: UILabel!
    @IBOutlet private weak var lblCompany: UILabel!
    @IBOutlet private weak var lblEmail: UILabel!
    
    var viewModel: UserDetailViewModel!
    var disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup() {
        self.imgUser.layer.cornerRadius = 64
        viewModel.headerTitle.bind(to: self.navigationItem.rx.title).disposed(by: disposeBag)
        viewModel.userName.bind(to: self.lblUserName.rx.text).disposed(by: disposeBag)
        viewModel.location.bind(to: self.lblLocation.rx.text).disposed(by: disposeBag)
        viewModel.follower.bind(to: self.lblFollower.rx.text).disposed(by: disposeBag)
        viewModel.following.bind(to: self.lblFollowing.rx.text).disposed(by: disposeBag)
        viewModel.company.bind(to: self.lblCompany.rx.text).disposed(by: disposeBag)
        viewModel.email.bind(to: self.lblEmail.rx.text).disposed(by: disposeBag)
        viewModel.imageUrl.subscribe { url in
            CommonUtility.setImage(imageView: self.imgUser, url: url)
        }.disposed(by: disposeBag)
    }
    
    
}
