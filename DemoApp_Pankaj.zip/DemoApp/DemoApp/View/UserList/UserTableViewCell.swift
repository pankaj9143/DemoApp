//
//  UserTableViewCell.swift
//  DemoApp
//
//  Created by Pankaj Purohit on 26/08/22.
//

import Foundation
import UIKit

class UserTableViewCell: UITableViewCell {
    @IBOutlet private weak var imgUser: UIImageView!
    @IBOutlet private weak var lblUserName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        accessoryType = .disclosureIndicator
    }
    
    func setData(user: UserModel) {
        let imageUrl = URL(string: user.avatarUrl)
        imgUser.kf.setImage(
            with: imageUrl,
            placeholder: UIImage(named: "placeHolder.png"),
            options: [
                .loadDiskFileSynchronously,
                .cacheOriginalImage,
                .transition(.fade(0.25))
            ],
            progressBlock: { receivedSize, totalSize in
            },
            completionHandler: { result in
            }
        )
        lblUserName.text = user.login.capitalized
        if CommonUtility.getUser(key: "\(user.userId)") {
            lblUserName.textColor = .gray
            lblUserName.font = UIFont.systemFont(ofSize: 18)
        } else {
            lblUserName.textColor = .black
            lblUserName.font = UIFont.boldSystemFont(ofSize: 18)
        }
    }
}
