//
//  UserListViewController.swift
//  DemoApp
//
//  Created by Pankaj Purohit on 26/08/22.
//

import UIKit
import RxSwift
import Kingfisher

class UserListViewController: UIViewController {
    
    @IBOutlet weak var searchBar : UISearchBar!
    @IBOutlet private weak var tblUserList: UITableView!
    private var viewModel = UserListViewModel()
    private var disposeBag = DisposeBag()
    private let ACCEPTABLE_CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_ "
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Users"
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tblUserList.reloadData()
    }
    
    private func setup() {
        if let textfield = searchBar.value(forKey: "searchField") as? UITextField {
            textfield.backgroundColor = .white
        }
        
        viewModel.arrSearchUserList.bind(to: tblUserList.rx.items(cellIdentifier: "UserTableViewCell")) { row, userData, cell in
            guard let cell = cell as? UserTableViewCell else { return }
            cell.setData(user: userData)
        }.disposed(by: disposeBag)
        
        tblUserList.rx.itemSelected.subscribe(onNext: { [weak self] indexPath in
            guard let user = self?.viewModel.arrSearchUserList.value[indexPath.row] else { return }
            CommonUtility.saveUser(key: "\(user.userId)")
            let vm = UserDetailViewModel(login: user.login)
            let vc = self?.storyboard?.instantiateViewController(withIdentifier: "UserDetailViewController") as! UserDetailViewController
            vc.viewModel = vm
            self?.navigationController?.pushViewController(vc, animated: true)
            self?.tblUserList.deselectRow(at: indexPath, animated: true)
        }).disposed(by: disposeBag)
        
        viewModel.getUserList()
    }
    
    private func searchUser(search: Bool) {
        if search {
            let searchedData = viewModel.arrUserList.value.filter({ $0.login.localizedCaseInsensitiveContains(self.searchBar.text!)})
            viewModel.arrSearchUserList.accept(searchedData)
        } else {
            viewModel.arrSearchUserList.accept(viewModel.arrUserList.value)
        }
    }
}

extension UserListViewController: UISearchBarDelegate
{
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = false
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        let cs = NSCharacterSet(charactersIn: ACCEPTABLE_CHARACTERS).inverted
        let filtered = text.components(separatedBy: cs).joined(separator: "")
        return (text == filtered)
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchUser(search: searchBar.text!.count > 0)
    }
    
}


