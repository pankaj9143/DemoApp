//
//  UserDetailViewModel.swift
//  DemoApp
//
//  Created by Pankaj Purohit on 26/08/22.
//

import Foundation
import RxCocoa

class UserDetailViewModel {
    let headerTitle = BehaviorRelay<String>(value: "")
    let userName = BehaviorRelay<String>(value: "")
    let location = BehaviorRelay<String>(value: "")
    let follower = BehaviorRelay<String>(value: "")
    let following = BehaviorRelay<String>(value: "")
    let email = BehaviorRelay<String>(value: "-")
    let company = BehaviorRelay<String>(value: "")
    let imageUrl = BehaviorRelay<String>(value: "")
    
    init(login: String) {
        self.headerTitle.accept(login)
        self.getUserDetail(user: login)
    }
    
    func getUserDetail(user: String) {
        WebAPIManager.shared.callWebService(serviceName: "\(WS_USERS)/\(user)", method: .get, parameter: [String : Any]()) { data in
            do {
                let jsonDecoder = JSONDecoder()
                let detail = try jsonDecoder.decode(UserModel.self, from: data)
                self.userName.accept("User Name : \(detail.name ?? "-")")
                self.location.accept("Location : \(detail.location ?? "-")")
                self.follower.accept("Followers : \(detail.followers ?? 0)")
                self.following.accept("Following : \(detail.following ?? 0)")
                self.company.accept("Company : \(detail.company ?? "-")")
                self.email.accept("Email : \(detail.email ?? "-")")
                self.imageUrl.accept(detail.avatarUrl)
            } catch {
                print("Error while decoding response: \(String(data: data, encoding: .utf8) ?? "")")
            }
        } failure: { error in
        }
    }
}
