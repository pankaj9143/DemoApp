//
//  UserListViewModel.swift
//  DemoApp
//
//  Created by Pankaj Purohit on 26/08/22.
//

import Foundation
import RxCocoa

class UserListViewModel {
    let arrUserList = BehaviorRelay<[UserModel]>(value: [])
    let arrSearchUserList = BehaviorRelay<[UserModel]>(value: [])
    
    init() {
    }
    
    func getUserList() {
        WebAPIManager.shared.callWebService(serviceName: WS_USERS, method: .get, parameter: [String : Any]()) { data in
            do {
                let jsonDecoder = JSONDecoder()
                let userList = try jsonDecoder.decode([UserModel].self, from: data)
                self.arrUserList.accept(userList)
                self.arrSearchUserList.accept(userList)
            } catch {
                print("Error while decoding response: \(String(data: data, encoding: .utf8) ?? "")")
            }
        } failure: { error in
        }
    }
}
